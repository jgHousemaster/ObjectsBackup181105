#define VERSION_NO "0.55"
#define VERSION_DATE "20081024"

#define VITETRIS_VER "vitetris "VERSION_NO
