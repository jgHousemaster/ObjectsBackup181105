There are two programs included in this zip-file.
They should work on Windows 95 (you need msvcrt.dll) or newer.

TETRIS.EXE    Console application
TETRISAL.EXE  Statically linked with Allegro, need DirectX 7 (or newer)

If you get a message that SUnMapLS_IP_EBP_12 could not be located in
KERNEL32.dll, try to run in compatibility mode.

See README.txt for more information.